"""
Rule-based problem-span extractor for eoreader6's problem corpus.

No model generation anywhere in this file — pure regex/marker matching over
fetched or local text, consistent with the no-LLM-in-load-path commitment.
Emits PROBLEM_SPAN_INGEST events matching the schema in
PROBLEM_CORPUS_SPEC.md, one JSON object per line (JSONL), ready to append
into your existing EO event log.

Usage:
    python extract_problem_spans.py --domain turbulence --file mytext.txt
    python extract_problem_spans.py --domain nl_complexity --wikipedia "Ambiguity"
"""

import argparse
import hashlib
import json
import re
import sys
import urllib.request
import urllib.parse

# --- narrow, literal marker lexicon (see spec section 3) --------------------
MARKERS = {
    "unresolved_status": [
        r"\bremains? unsolved\b",
        r"\ban open (problem|question)\b",
        r"\bis not (yet )?fully understood\b",
        r"\bstill debated\b",
        r"\bno exact solution\b",
        r"\bno consensus\b",
    ],
    "disagreement": [
        r"\bin contrast to\b.{0,60}\bargues?\b",
        r"\bcompeting (accounts?|theories|explanations)\b",
        r"\bis contested\b",
    ],
    "existence_wellposedness": [
        r"\bexistence and smoothness\b",
        r"\bwhether solutions exist\b",
        r"\bwell-?posedness\b",
    ],
    "ambiguity": [
        r"\bmultiple readings?\b",
        r"\bscope ambiguity\b",
        r"\bambiguous (reference|attachment)\b",
    ],
}

COMPILED = {
    cat: [re.compile(p, re.IGNORECASE) for p in pats]
    for cat, pats in MARKERS.items()
}

SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


def split_sentences(text: str):
    text = re.sub(r"\s+", " ", text).strip()
    return SENTENCE_SPLIT.split(text)


def span_id(source: str, text: str) -> str:
    return hashlib.sha256((source + text).encode("utf-8")).hexdigest()[:16]


def extract_spans(text: str, source: str, domain: str, context: int = 2):
    """Scan sentence-by-sentence; on a marker hit, emit the sentence plus
    +/- `context` surrounding sentences as grounding context."""
    sentences = split_sentences(text)
    events = []
    for i, sent in enumerate(sentences):
        for category, patterns in COMPILED.items():
            for pat in patterns:
                if pat.search(sent):
                    lo = max(0, i - context)
                    hi = min(len(sentences), i + context + 1)
                    span_text = " ".join(sentences[lo:hi])
                    events.append({
                        "event_type": "PROBLEM_SPAN_INGEST",
                        "domain": domain,
                        "source": source,
                        "span_text": span_text,
                        "marker_matched": category,
                        "matched_sentence": sent,
                        "ingest_pass": 0,
                        "prior_verdict": None,
                        "prior_surprisal_microbits": None,
                        "span_id": span_id(source, span_text),
                    })
                    break  # one match per sentence is enough
    return events


def fetch_wikipedia(title: str) -> str:
    """Pull plain extract text from the Wikipedia API (no auth needed)."""
    params = urllib.parse.urlencode({
        "action": "query",
        "prop": "extracts",
        "explaintext": 1,
        "format": "json",
        "titles": title,
    })
    url = f"https://en.wikipedia.org/w/api.php?{params}"
    with urllib.request.urlopen(url, timeout=20) as resp:
        data = json.load(resp)
    pages = data.get("query", {}).get("pages", {})
    for page in pages.values():
        return page.get("extract", "")
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--domain", required=True,
                     choices=["turbulence", "nl_complexity",
                              "complexity_emergence", "meta"])
    ap.add_argument("--file", help="local text file to scan")
    ap.add_argument("--wikipedia", help="Wikipedia article title to fetch and scan")
    ap.add_argument("--out", default="problem_spans.jsonl")
    args = ap.parse_args()

    if not args.file and not args.wikipedia:
        sys.exit("Provide --file or --wikipedia")

    if args.wikipedia:
        text = fetch_wikipedia(args.wikipedia)
        source = f"wikipedia:{args.wikipedia}"
    else:
        with open(args.file, "r", encoding="utf-8") as f:
            text = f.read()
        source = args.file

    events = extract_spans(text, source, args.domain)

    with open(args.out, "a", encoding="utf-8") as f:
        for e in events:
            f.write(json.dumps(e, ensure_ascii=False) + "\n")

    print(f"Extracted {len(events)} problem spans from {source} -> {args.out}")


if __name__ == "__main__":
    main()
