# eoreader6: Problem-Corpus Pipeline (NL complexity / complexity-emergence / turbulence)

## 1. Purpose

Feed eoreader6 a stream of *hard, contested, genuinely unresolved* text spans
drawn from four domains, and use the engine's own instrumentation
(ρ, surprisal_microbits, verdict space) to measure competency growth as
repeated exposure collapses `contested`/`thrash`/`void` spans toward
`settled`/`supported` — with each collapse logged as a typed **AHA event**.

This is not a training loop in the ML sense. Nothing is fit or generated.
The engine reads the same corpus across K passes; what changes is *its own
prior*, which is why the delta between prior-relative and posterior-relative
surprisal is the signal we care about, not accuracy against a label.

No LLM touches corpus construction or span extraction — everything below is
rule-based / API-based, consistent with the no-generation-in-load-path
commitment. The four domains are chosen because each has a *documented,
citable, admits-it's-unsolved* character, which gives you problem spans with
real epistemic weight instead of synthetic ambiguity.

## 2. The four corpora

| Domain | Why it's rich in genuine contested/void material | Primary sources |
|---|---|---|
| **Natural language complexity** | Ambiguity, coreference, and pragmatic inference are exactly the "no single reading is settled" case your verdict space is built for | WinoGrande, Winograd Schema Challenge, PDTB (discourse relations), garden-path sentence corpora, PragmEval |
| **Complexity science / emergence** | The field's own literature is full of explicit "this remains phenomenological / unresolved" hedges | Santa Fe Institute working papers, the complexity/emergence survey literature, review articles with open-problem sections |
| **Turbulence** | Closure problem is a *named, 130-year-old, still-open* problem with a rich rhetorical vocabulary of unsolvedness | Nelkin's "unsolved problem" pieces, Navier-Stokes existence/smoothness (Clay problem), JHTDB dataset documentation, review articles in Physics of Fluids / JFM |
| **Meta: cross-domain "hard problem" registries** | Gives you a control set of *canonically agreed-open* problems to calibrate the marker lexicon against | Clay Millennium Problems, Hilbert-style open-problem lists, NLP leaderboards where SOTA is still far below human baseline |

Each corpus should be pulled as **raw source text**, not summaries — the
engine needs verbatim spans to ground provenance against, per the
about ≠ says commitment.

## 3. What counts as a "problem span"

A problem span is a verbatim passage that a domain-expert source itself
marks as unresolved, contested, or actively debated — not a span Claude or
any model judges to be hard. The marker lexicon should stay narrow and
literal so extraction is a grep-able, auditable operation:

- **Unresolved-status markers**: "remains unsolved", "an open problem",
  "is not fully understood", "still debated", "no exact solution",
  "phenomenological" (as a hedge, not a description)
- **Disagreement markers**: "in contrast to X, Y argues", "there is no
  consensus on", "competing accounts of"
- **Existence/well-posedness markers** (turbulence/math-specific):
  "existence and smoothness", "whether solutions exist"
- **Ambiguity markers** (NL-specific): sentences flagged by a corpus's own
  annotation as multi-reading, or containing scope/attachment ambiguity per
  the source dataset's schema (don't invent new ambiguity — use the
  dataset's own gold-standard ambiguity flags)

This lexicon is intentionally small. A larger, categorized lexicon buys
little extraction value and starts to look like a manipulation script for
whoever reads the spec — keep it to what's needed to grep responsibly, and
let the engine's own ρ/verdict machinery do the actual epistemic work.

## 4. Event schema (extends the existing append-only log)

```json
{
  "event_type": "PROBLEM_SPAN_INGEST",
  "domain": "turbulence | nl_complexity | complexity_emergence | meta",
  "source": "<citation or URL>",
  "span_text": "<verbatim>",
  "marker_matched": "<which lexicon entry fired>",
  "ingest_pass": 0,
  "prior_verdict": null,
  "prior_surprisal_microbits": null
}
```

On each subsequent read pass (K-run), the engine appends:

```json
{
  "event_type": "PROBLEM_SPAN_REREAD",
  "span_id": "<ref to ingest event>",
  "pass": 1,
  "verdict": "contested | thrash | void | supported | settled",
  "surprisal_microbits": { "prior_relative": ..., "posterior_relative": ... },
  "rho": ...
}
```

## 5. Defining the AHA event

An AHA event is a specific, typed, loggable transition — not a vibe:

```
AHA_EVENT fires when, between pass N and pass N+1 on the same span:
  verdict(N)   ∈ {contested, thrash, void}
  verdict(N+1) ∈ {supported, settled}
  AND posterior_bayes_microbits(N+1) drops by more than threshold δ
      relative to posterior_bayes_microbits(N)
```

The magnitude of the drop *is* the joy signal — not a separate emotion
model bolted on top. This keeps "joy of aha" inside the existing honesty
architecture (Part VI) rather than inventing new machinery: it's a
first-class, typed, re-inspectable event in the same log as everything
else, falsifiable the same way witness-coverage and void-fidelity are.

Competency, in aggregate, is the AHA-event rate over a corpus pass, plus
the shrinking share of spans still returning `void` on repeated exposure.
A corpus where AHA rate never rises across passes tells you the span
selection was actually noise, not genuine unresolved material — useful
as a negative control.

## 6. Pipeline stages

1. **Fetch** — pull raw text per domain (script below handles Wikipedia +
   local file ingestion; arXiv/JHTDB docs need to be fetched from your own
   network since this sandbox can't reach those domains).
2. **Extract** — grep/regex marker pass over fetched text, emit candidate
   problem spans with surrounding context (±2 sentences) for grounding.
3. **De-dup / domain-balance** — cap spans per source so no single review
   article dominates the corpus.
4. **Emit EO events** — write `PROBLEM_SPAN_INGEST` events into your
   existing append-only log format.
5. **Run K passes through eoreader6** — no changes needed on the engine
   side beyond logging `PROBLEM_SPAN_REREAD` and computing AHA_EVENT as a
   derived event (could be a small post-hoc pass over the log rather than
   inline in the read path, keeping it outside the load-bearing engine).
6. **Report** — AHA rate per domain per pass, void-share decay curve,
   prior- vs posterior-relative surprisal divergence over time.

## 7. Open design questions (for you, not resolved here)

- Should AHA threshold δ be domain-relative (turbulence spans may run
  "hotter" prior surprisal than NL ambiguity spans) or global?
- Does a span get re-ingested if its source is later joined by a second
  source using the same marker (corroboration vs. repetition)?
- Should `void`-status spans that never resolve across all K passes get
  flagged as a distinct "genuinely irreducible" class, separate from
  spans that are just under-read?
